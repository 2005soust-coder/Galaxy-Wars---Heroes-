# Galaxy Wars - Heroes

Android aplikace pro losování hrdinů deskové hry Galaxy Wars.

- 2 až 5 hráčů
- každý hráč získá 2 různé hrdiny
- žádný hrdina se během jedné hry neopakuje
- výběr dostupných hrdinů před začátkem hry
- kompletní karty se zobrazují bez ořezávání

## Sestavení APK
Projekt používá Android Gradle Plugin 8.6.1, Gradle 8.7, Javu 17 a Android SDK 35.

V GitHub Actions spusťte workflow **Build Galaxy Wars Heroes APK**.
